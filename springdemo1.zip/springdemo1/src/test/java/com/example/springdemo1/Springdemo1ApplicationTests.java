package com.example.springdemo1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springdemo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
